<?php
const pageErrorInfo = '页面出现了一些问题，暂时无法显示。';
