<?php

return [
    'user_notlogin' => '用户未登录',
    'account_forbidden' => '账号已被禁用',
    'logout' => '退出登录',
    'develop_tools_menu' => '开发集成',
    'overview' => '概况',
];
